//
//  GenericDevices.h
//  GenericDevices
//
//  Created by leonardo.a.simoza on 8/03/22.
//

#import <Foundation/Foundation.h>

//! Project version number for GenericDevices.
FOUNDATION_EXPORT double GenericDevicesVersionNumber;

//! Project version string for GenericDevices.
FOUNDATION_EXPORT const unsigned char GenericDevicesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GenericDevices/PublicHeader.h>


#import "BBDeviceCAPK.h"
#import "BBDeviceController.h"
#import "BBDeviceOTAController.h"
#import "BBDeviceVASMerchantConfig.h"
